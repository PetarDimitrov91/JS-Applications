import {View} from "./View.js";

export class AddView extends View {
    constructor(section) {
        super(section);
    }
}