import {View} from "./View.js";

export class RegisterView extends View {
    constructor(section) {
        super(section);
    }
}