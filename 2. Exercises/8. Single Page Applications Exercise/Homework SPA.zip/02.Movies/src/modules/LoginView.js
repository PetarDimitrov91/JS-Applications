import {View} from "./View.js";

export class LoginView extends View{
    constructor(section) {
        super(section);
    }
}